% load the binned data
% this isn't working yet, we don't do this very often

starting_file_number=1;
file_type_id=0.1;
number_of_bins=10;

for(i=starting_file_number:number_of_bins)
    TDMI_binned_patient_data(=load();
    
end;


